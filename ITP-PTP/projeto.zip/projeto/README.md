# Projeto ITP/PTP

Aluno: Thiago Anderson Costa

## Checkpoint 1: Leitura de imagem